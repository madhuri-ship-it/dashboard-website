# Deploying the Vurve dashboard on Google Cloud

For the person with Google Cloud access (IT). About 1 to 2 hours the first time.
Replace the CAPITAL words. Commands were written from Google's documented patterns but
could not be run from where this package was built, so run them step by step and
check each result. If a command differs on your gcloud version, the Cloud Console
does the same thing.

## What gets created

| Piece | What it does |
|---|---|
| Cloud Run service `vurve-dashboard` | The website. Sits behind Google sign-in (Identity-Aware Proxy, IAP). |
| Cloud Run job `vurve-refresh` | Reads the two Drive workbooks and the access sheet, rebuilds the data. |
| Cloud Scheduler | Starts the job every hour from 7:00 to 21:00 India time. It only rebuilds when Drive files changed. |
| Cloud Storage bucket | Private store for data.json, access.json, state.json and config. |
| Service account `vurve-dash-sa` | The identity the website and job run as. |

## 0. Before you start
- A Google Cloud project with billing on, and you are Owner or Editor on it.
- gcloud installed and logged in: `gcloud auth login` then `gcloud config set project PROJECT_ID`.
- Pick a region. Examples below use `asia-south1` (Mumbai).

```
export PROJECT_ID=PROJECT_ID
export REGION=asia-south1
export BUCKET=${PROJECT_ID}-vurve-dashboard-data
export SA=vurve-dash-sa@${PROJECT_ID}.iam.gserviceaccount.com
```

## 1. Switch on the services
```
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com \
  storage.googleapis.com drive.googleapis.com sheets.googleapis.com cloudscheduler.googleapis.com iap.googleapis.com
```

## 2. Private bucket and service account
```
gcloud storage buckets create gs://$BUCKET --location=$REGION --uniform-bucket-level-access --public-access-prevention
gcloud iam service-accounts create vurve-dash-sa --display-name="Vurve dashboard"
gcloud storage buckets add-iam-policy-binding gs://$BUCKET --member=serviceAccount:$SA --role=roles/storage.objectAdmin
```

## 3. Give the service account read access to your Google files
In Google Drive, share each of these with the service account email (`vurve-dash-sa@PROJECT_ID.iam.gserviceaccount.com`) as **Viewer**:
- the folder with `outlet_sales_history_2026.xlsx` and `employee_history_2026.xlsx` (note the folder id from its URL),
- the access sheet (step 4),
- the incentive report only if you want it read from Drive (otherwise upload a copy in step 5).

## 4. The access sheet
1. Upload `deploy/access_sheet_template.xlsx` to Google Drive and open it with Google Sheets (File, Save as Google Sheets).
2. Replace the example rows with your real clusters and managers. The Read me tab explains each column.
3. Note the sheet id (the long text in its URL). Share it with the service account (step 3).

This sheet is the only place that decides who sees what. Only the people who may edit it control access.

## 5. Put the starting config into the bucket
```
gcloud storage cp config/targets.json gs://$BUCKET/config/targets.json
gcloud storage cp seed/incentive.xlsx gs://$BUCKET/config/incentive.xlsx
```
`incentive.xlsx` contains staff salaries. Keep the bucket private and delete the local copy of `seed/` once uploaded.
Salon targets live in `targets.json` and staff targets and salaries in `incentive.xlsx`. To change them later, upload a new file to the same path. Run the job with `FORCE=1` afterwards.

## 6. Deploy the website
```
gcloud beta run deploy vurve-dashboard --source . --region $REGION \
  --service-account $SA --no-allow-unauthenticated --iap \
  --min-instances 0 --max-instances 3 --memory 512Mi \
  --set-env-vars DATA_BUCKET=$BUCKET,ALLOWED_DOMAINS=vurvesalon.com
```
Then let IAP call the service and let your company domain through the Google sign-in step:
```
PROJECT_NUMBER=$(gcloud projects describe $PROJECT_ID --format='value(projectNumber)')
gcloud run services add-iam-policy-binding vurve-dashboard --region $REGION \
  --member=serviceAccount:service-${PROJECT_NUMBER}@gcp-sa-iap.iam.gserviceaccount.com --role=roles/run.invoker
gcloud beta iap web add-iam-policy-binding --resource-type=cloud-run --service=vurve-dashboard --region=$REGION \
  --member=domain:vurvesalon.com --role=roles/iap.httpsResourceAccessor
```
Letting the whole domain through IAP is fine. The app itself then checks every person against the access sheet and shows "No access" to anyone not listed.

**Important, the audience setting.** The app verifies the IAP signature and needs the audience value.
Open Cloud Console, Security, Identity-Aware Proxy, find `vurve-dashboard`, choose "Get JWT audience" (copy the "Signed Header JWT audience"), then:
```
gcloud run services update vurve-dashboard --region $REGION --update-env-vars IAP_AUDIENCE="THE_AUDIENCE_VALUE"
```
Without it, everyone gets "Sign-in required". That is the safe failure.

## 7. Deploy the refresh job and run it once
```
gcloud run jobs deploy vurve-refresh --source . --region $REGION --service-account $SA \
  --command python --args=-m,refresh.refresh_job --max-retries 1 --task-timeout 900s --memory 1Gi \
  --set-env-vars DATA_BUCKET=$BUCKET,DRIVE_FOLDER_ID=FOLDER_ID,ACCESS_SHEET_ID=SHEET_ID
gcloud run jobs execute vurve-refresh --region $REGION --wait
```
Check the log shows `data_published` and `access_published`. If it says the files were not found, they are not shared with the service account yet.

If you see an authentication or scope error reading Drive or Sheets, the default Cloud Run identity could not get the Drive/Sheets permission. Create a key for the service account, store it in Secret Manager, and mount it as `GOOGLE_APPLICATION_CREDENTIALS`. Use this only if needed.

## 8. Schedule it
```
gcloud iam service-accounts create vurve-scheduler
gcloud run jobs add-iam-policy-binding vurve-refresh --region $REGION \
  --member=serviceAccount:vurve-scheduler@${PROJECT_ID}.iam.gserviceaccount.com --role=roles/run.invoker
gcloud scheduler jobs create http vurve-refresh-hourly --location $REGION \
  --schedule="0 7-21 * * *" --time-zone="Asia/Kolkata" --http-method=POST \
  --uri="https://${REGION}-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/${PROJECT_ID}/jobs/vurve-refresh:run" \
  --oauth-service-account-email=vurve-scheduler@${PROJECT_ID}.iam.gserviceaccount.com
```
The Zenoti files have been landing on Drive at different times of the morning, which is why it runs hourly and only rebuilds when a file changed.

## 9. Test before telling anyone
1. Open the service URL (Console, Cloud Run, vurve-dashboard) signed in as an admin: you should see all 15 salons.
2. Open it as a manager: only their cluster's salons, no salary, and the top line shows their cluster name.
3. Open it as someone not on the sheet: "No access yet".
4. In a private window not signed in: you are sent to Google sign-in, never to data.
5. Right-click, View page source as a manager and search for another cluster's salon name: it must not be there.

## 10. Alerts (recommended)
- Cloud Monitoring alert when the job `vurve-refresh` fails (log line `refresh_failed`).
- The website shows whatever data was last published, so a failed refresh means stale data, never wrong data.

## Day-to-day
- Add or remove a manager, change a cluster: edit the access sheet. Live within the next hourly run.
- New month targets: upload the new `targets.json`, then `gcloud run jobs execute vurve-refresh --region $REGION --update-env-vars FORCE=1 --wait`.
- Staff target or salary changes: upload a new `incentive.xlsx` the same way.
- Update the dashboard code: `gcloud beta run deploy vurve-dashboard --source . ...` again (and redeploy the job).
- Audit: the service logs one line per page view with the email and salon count (Cloud Logging).

## Not tested from the build environment
The sign-in check against real Google IAP, reading real Drive and Sheets as the service account, and the gcloud commands above. Everything else (filtering, access rules, data build matching the live dashboard, charts under the security headers) was tested. Do steps 9 and the Drive read in step 7 before announcing it.
