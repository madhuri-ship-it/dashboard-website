"""Build local_data/ from three Excel files so you can run the site on your own computer.
Usage: python tools/build_local.py outlet.xlsx employee.xlsx incentive.xlsx you@vurvesalon.com
Then: DEV_USER=you@vurvesalon.com flask --app app.main run
"""
import json, os, sys
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from refresh import build_data

outlet, emp, inc, me = sys.argv[1:5]
cfg = json.load(open(os.path.join(os.path.dirname(__file__), "..", "config", "targets.json")))
data = build_data.build(pd.read_excel(outlet), pd.read_excel(emp), pd.read_excel(inc, sheet_name="Incentive", header=3),
                        cfg["salons"], cfg["tier_months"])
out = os.path.join(os.path.dirname(__file__), "..", "local_data"); os.makedirs(out, exist_ok=True)
json.dump(data, open(os.path.join(out, "data.json"), "w"), separators=(",", ":"))
json.dump({"clusters": {}, "users": {me.lower(): {"name": "Me", "role": "admin", "clusters": [], "salons": [], "salary": True}}},
          open(os.path.join(out, "access.json"), "w"))
print("wrote local_data/ through", data["meta"]["data_through"])
