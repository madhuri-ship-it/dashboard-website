# Vurve Executive Performance Intelligence: web version

One login-protected link for the whole team. Each person sees only the salons they are
allowed to see, and the other salons' numbers are never sent to their browser.

## How it works
1. Managers open the link and sign in with their vurvesalon.com Google account (Google Identity-Aware Proxy).
2. The server checks the email against the access sheet, keeps only that person's salons and staff, removes salary unless allowed, and builds the page.
3. A scheduled job reads `outlet_sales_history_2026.xlsx` and `employee_history_2026.xlsx` from Drive each hour and rebuilds the data only when they change.
4. The dashboard itself (all three tabs, date picker, filters, popups) is the same one already published.

```
Drive files --> refresh job --> private bucket (data.json, access.json)
                                          |
 Manager --> Google sign-in (IAP) --> web service --> filter by email --> page
```

## Folder guide
- `app/` the website (`main.py`, sign-in check `auth.py`, who-sees-what `access.py`, page templates, charts library)
- `refresh/` the daily rebuild (`build_data.py` calculations, `drive_io.py`, `access_sheet.py`, `refresh_job.py`)
- `config/targets.json` monthly salon targets and tier months (September figures for now)
- `seed/incentive.xlsx` staff targets and salaries. Contains salaries: upload to the private bucket, then delete this copy.
- `deploy/DEPLOY.md` step by step setup for IT, `deploy/access_sheet_template.xlsx` the access sheet to start from
- `tests/` and `tools/` checks and a local-run helper

## Who sees what (access sheet)
Users tab: Email, Name, Role (admin or manager), Clusters, Salons, Salary (yes/no).
Clusters tab: Cluster name and its salons. Not on the sheet means "No access yet".

## Run on your own computer
```
pip install -r requirements.txt
python tools/build_local.py outlet.xlsx employee.xlsx seed/incentive.xlsx you@vurvesalon.com
DEV_USER=you@vurvesalon.com flask --app app.main run
```
`DEV_USER` skips the Google sign-in and is refused automatically when running on Cloud Run.

## Checks that were run
- `python tests/test_build_parity.py outlet.xlsx emp.xlsx inc.xlsx data.json` hosted build reproduces the published dashboard's numbers exactly (15 salons, 486 staff, same tiers).
- `python tests/test_access_web.py data.json` 19 checks: manager gets only their salons, no other salon name appears in the page, salary hidden, unknown email refused, forged headers refused, caching off, security headers set.
- Browser test with the security headers on: charts render for manager and admin, no script errors, tier buttons with no salons are hidden.

## Known limits
- Targets: one set of salon targets (September) is pro-rated for every date, including October. Per-month targets need a dashboard change; send the October targets and this can be added.
- Staff targets and salaries come from `incentive.xlsx` as of the August incentive report, until a newer one is uploaded.
- For a manager, "chain" comparisons mean the average of the salons they can see (the page says "cluster").
- Not tested here: the sign-in check against real Google IAP and reading real Drive/Sheets as the service account. See the end of `deploy/DEPLOY.md`.
- Data is only as complete as the Drive files. Recent days (for example 5 and 6 October) looked incomplete in the latest pull.
