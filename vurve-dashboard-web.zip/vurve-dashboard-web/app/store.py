"""Tiny storage layer: a private Google Cloud Storage bucket in production,
a local folder for development and tests.

Files used:
  data.json     full dataset built by the refresh job (never sent to browsers as-is)
  access.json   who may see what (built from the access Google Sheet)
  state.json    refresh bookkeeping (Drive modified times, last run)
  config/*      targets.json, incentive.xlsx (salary data, keep private)
"""
import json
import os
import time

_CACHE = {}
CACHE_SECONDS = int(os.environ.get("CACHE_SECONDS", "60"))


def _bucket():
    name = os.environ.get("DATA_BUCKET")
    if not name:
        return None
    from google.cloud import storage  # imported lazily so local runs need no GCP libs

    return storage.Client().bucket(name)


def _local_dir():
    d = os.environ.get("DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "local_data"))
    os.makedirs(d, exist_ok=True)
    return d


def read_bytes(name):
    b = _bucket()
    if b is not None:
        blob = b.blob(name)
        return blob.download_as_bytes() if blob.exists() else None
    path = os.path.join(_local_dir(), name)
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return f.read()


def write_bytes(name, data, content_type="application/octet-stream"):
    b = _bucket()
    if b is not None:
        b.blob(name).upload_from_string(data, content_type=content_type)
        return
    path = os.path.join(_local_dir(), name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)


def read_json(name, default=None, cached=True):
    now = time.time()
    hit = _CACHE.get(name)
    if cached and hit and now - hit[0] < CACHE_SECONDS:
        return hit[1]
    raw = read_bytes(name)
    val = json.loads(raw) if raw else default
    _CACHE[name] = (now, val)
    return val


def write_json(name, obj):
    write_bytes(name, json.dumps(obj, separators=(",", ":")).encode("utf-8"), "application/json")
    _CACHE.pop(name, None)
