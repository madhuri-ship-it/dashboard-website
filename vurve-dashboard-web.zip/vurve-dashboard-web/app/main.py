"""Vurve Executive Performance Intelligence: login-protected web app.

One page, one URL. The server decides what each signed-in person may see and
builds the page with only that data inside it.
"""
import json
import logging
import os

from flask import Flask, Response, abort

from . import access as acc
from . import auth, store

HERE = os.path.dirname(__file__)
app = Flask(__name__, static_folder=os.path.join(HERE, "static"), static_url_path="/static")
logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger("vurve")

_TEMPLATE = {}


def _template():
    if not _TEMPLATE:
        with open(os.path.join(HERE, "templates", "head.html"), encoding="utf-8") as f:
            head = f.read()
        with open(os.path.join(HERE, "templates", "body.html"), encoding="utf-8") as f:
            body = f.read()
        _TEMPLATE["head"], _TEMPLATE["body"] = head, body
    return _TEMPLATE["head"], _TEMPLATE["body"]


def _safe_json(obj):
    # keep "</script>" and line separators from ending the inline script early
    return (
        json.dumps(obj, separators=(",", ":"))
        .replace("<", "\\u003c")
        .replace(" ", "\\u2028")
        .replace(" ", "\\u2029")
    )


CSP = (
    "default-src 'none'; script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
    "font-src https://fonts.gstatic.com; img-src 'self' data:; "
    "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
)


def _headers(resp):
    resp.headers["Cache-Control"] = "private, no-store"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Content-Security-Policy"] = CSP
    return resp


def _page(message, status):
    html = (
        "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
        "<title>Vurve dashboard</title><body style='font:16px system-ui;max-width:520px;margin:15vh auto;padding:0 16px'>"
        f"<h2>{message[0]}</h2><p>{message[1]}</p></body>"
    )
    return _headers(Response(html, status=status, mimetype="text/html"))


@app.get("/healthz")
def healthz():
    return "ok"


@app.get("/")
def index():
    from flask import request

    try:
        email = auth.get_user_email(request)
    except auth.AuthError as exc:
        log.info(json.dumps({"event": "auth_fail", "reason": str(exc)}))
        return _page(("Sign-in required", "Please open this page through the company sign-in link."), 401)

    full = store.read_json("data.json")
    access = store.read_json("access.json", default={})
    if not full:
        return _page(("Data not ready yet", "The first data refresh has not run. Please try again later."), 503)
    try:
        data, user = acc.filter_data(full, access, email)
    except acc.NoAccess:
        log.info(json.dumps({"event": "no_access", "user": email}))
        return _page(
            ("No access yet", f"{email} is not set up to view this dashboard. Ask the dashboard owner to add you."),
            403,
        )

    head, body = _template()
    page = (
        "<!doctype html><html lang=en><head><meta charset=utf-8>"
        "<meta name=viewport content='width=device-width,initial-scale=1'>"
        + head
        + "</head><body>"
        + body.replace("__DATA__", _safe_json(data)).replace(
            "<!--PLOTLY-->", '<script src="/static/plotly.min.js"></script>'
        )
        + "</body></html>"
    )
    log.info(json.dumps({"event": "view", "user": email, "salons": len(data["salons"]), "role": user.get("role")}))
    return _headers(Response(page, mimetype="text/html"))
