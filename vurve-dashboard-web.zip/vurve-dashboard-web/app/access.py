"""Access rules and server-side filtering.

access.json layout (built by the refresh job from the access Google Sheet):
{
  "clusters": {"Chennai North": ["Anna Nagar", "Kilpauk"], ...},
  "users": {
    "founder@vurvesalon.com": {"name": "Founder", "role": "admin", "clusters": [], "salons": [], "salary": false},
    "mgr@vurvesalon.com":     {"name": "A Manager", "role": "manager", "clusters": ["Chennai North"], "salons": [], "salary": false}
  }
}

Rules: unknown email -> no access. admin -> every salon. manager -> union of the
salons in their clusters plus any salons listed on their own row. Salary data is
removed unless the user's row says salary = true. Filtering happens here, on the
server, so a manager's browser never receives another cluster's numbers.
"""


class NoAccess(Exception):
    pass


def resolve(access, email):
    user = (access or {}).get("users", {}).get(email.lower())
    if not user:
        raise NoAccess(email)
    return user


def allowed_salons(access, user, all_salons):
    if user.get("role") == "admin":
        return list(all_salons)
    names = set(user.get("salons") or [])
    for c in user.get("clusters") or []:
        names.update(access.get("clusters", {}).get(c, []))
    return [s for s in all_salons if s in names]


def filter_data(full, access, email):
    """Return (data_for_this_user, user_row). Raises NoAccess."""
    user = resolve(access, email)
    all_names = [s["name"] for s in full["salons"]]
    names = allowed_salons(access, user, all_names)
    if not names:
        raise NoAccess(email)
    keep = set(names)
    show_salary = bool(user.get("salary"))
    staff = []
    for r in full["staff"]:
        if r["outlet"] not in keep:
            continue
        r = dict(r)
        if not show_salary:
            r["sal"] = None
        staff.append(r)
    is_admin = user.get("role") == "admin"
    if is_admin:
        scope = "All salons"
    elif user.get("clusters"):
        scope = ", ".join(user["clusters"])
    else:
        scope = "Your salons"
    out = {
        "dates": full["dates"],
        "salons": [s for s in full["salons"] if s["name"] in keep],
        "staff": staff,
        "meta": {
            "scope": scope,
            "chain": "chain" if is_admin else "cluster",
            "user": email.lower(),
            "data_through": full.get("meta", {}).get("data_through"),
        },
    }
    return out, user
