"""Who is asking? Google Identity-Aware Proxy (IAP) signs in the user and puts a
signed token in the X-Goog-IAP-JWT-Assertion header. We verify that signature
ourselves, so a request that did not come through IAP can never pass as a user.
"""
import os

IAP_CERTS_URL = "https://www.gstatic.com/iap/verify/public_key"


class AuthError(Exception):
    pass


def _dev_user():
    u = os.environ.get("DEV_USER")
    if u and os.environ.get("K_SERVICE"):
        # K_SERVICE is set on Cloud Run. Never allow the bypass there.
        raise RuntimeError("DEV_USER must not be set on Cloud Run")
    return u.strip().lower() if u else None


def get_user_email(request):
    dev = _dev_user()
    if dev:
        return dev
    token = request.headers.get("X-Goog-IAP-JWT-Assertion")
    if not token:
        raise AuthError("missing IAP token")
    audience = os.environ.get("IAP_AUDIENCE")
    if not audience:
        raise AuthError("IAP_AUDIENCE is not configured")
    from google.auth.transport import requests as grequests
    from google.oauth2 import id_token

    try:
        claims = id_token.verify_token(
            token, grequests.Request(), audience=audience, certs_url=IAP_CERTS_URL
        )
    except Exception as exc:  # bad signature, expired, wrong audience...
        raise AuthError(f"invalid IAP token: {exc}")
    email = (claims.get("email") or "").lower()
    if not email:
        raise AuthError("token has no email")
    allowed = [d.strip().lower() for d in os.environ.get("ALLOWED_DOMAINS", "").split(",") if d.strip()]
    if allowed and email.split("@")[-1] not in allowed:
        raise AuthError("email domain not allowed")
    return email
