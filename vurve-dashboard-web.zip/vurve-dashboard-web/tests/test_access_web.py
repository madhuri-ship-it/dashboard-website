"""Security tests: who sees what. Run: python tests/test_access_web.py <path to a full data.json>"""
import json, os, re, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
full_path = sys.argv[1]
tmp = tempfile.mkdtemp()
os.environ["DATA_DIR"] = tmp
os.environ.pop("DATA_BUCKET", None); os.environ.pop("K_SERVICE", None)
full = json.load(open(full_path))
json.dump(full, open(os.path.join(tmp, "data.json"), "w"))
names = [s["name"] for s in full["salons"]]
north = ["Anna Nagar", "Kilpauk"]
access = {"clusters": {"North": north, "Solo": ["Kochi"]},
          "users": {"founder@vurvesalon.com": {"name": "F", "role": "admin", "clusters": [], "salons": [], "salary": False},
                    "owner@vurvesalon.com": {"name": "O", "role": "admin", "clusters": [], "salons": [], "salary": True},
                    "north@vurvesalon.com": {"name": "N", "role": "manager", "clusters": ["North"], "salons": [], "salary": False},
                    "northsal@vurvesalon.com": {"name": "NS", "role": "manager", "clusters": ["North"], "salons": ["Kochi"], "salary": True},
                    "empty@vurvesalon.com": {"name": "E", "role": "manager", "clusters": [], "salons": [], "salary": False}}}
json.dump(access, open(os.path.join(tmp, "access.json"), "w"))
from app.main import app
c = app.test_client()
def get(email=None, headers=None):
    if email: os.environ["DEV_USER"] = email
    else: os.environ.pop("DEV_USER", None)
    return c.get("/", headers=headers or {})
def payload(html):
    m = re.search(r"const D=(\{.*?\});\n", html, re.S)
    return json.loads(m.group(1))
ok = 0
def check(cond, msg):
    global ok
    assert cond, "FAIL: " + msg
    ok += 1; print("  ok -", msg)

r = get("north@vurvesalon.com"); h = r.get_data(as_text=True); d = payload(h)
check(r.status_code == 200, "manager gets 200")
check([s["name"] for s in d["salons"]] == north, "manager receives only their cluster's salons")
others = [n for n in names if n not in north]
check(not any(n in h for n in others), "no other salon name appears anywhere in the page")
check(all(s["outlet"] in north for s in d["staff"]), "only staff of their salons")
check(all(s["sal"] is None for s in d["staff"]), "salary removed for manager without salary right")
check(d["meta"]["chain"] == "cluster" and d["meta"]["user"] == "north@vurvesalon.com", "meta set for manager")
check("Cache-Control" in r.headers and "no-store" in r.headers["Cache-Control"], "no-store caching")
check("Content-Security-Policy" in r.headers, "CSP header present")

r = get("northsal@vurvesalon.com"); d = payload(r.get_data(as_text=True))
check(sorted(s["name"] for s in d["salons"]) == sorted(north + ["Kochi"]), "cluster + extra salon union")
check(any(s["sal"] for s in d["staff"]), "salary shown when row allows it")

r = get("founder@vurvesalon.com"); d = payload(r.get_data(as_text=True))
check(len(d["salons"]) == len(names), "admin sees all salons")
check(all(s["sal"] is None for s in d["staff"]), "admin without salary right gets no salary")
r = get("owner@vurvesalon.com"); d = payload(r.get_data(as_text=True))
check(any(s["sal"] for s in d["staff"]), "admin with salary right gets salary")

check(get("stranger@vurvesalon.com").status_code == 403, "unknown email -> 403")
check(get("empty@vurvesalon.com").status_code == 403, "manager with no salons -> 403")
check(get("NORTH@VurveSalon.com").status_code == 200, "email match is case-insensitive")
check(get(None).status_code == 401, "no IAP token -> 401")
os.environ["IAP_AUDIENCE"] = "/projects/1/locations/x/services/y"
check(get(None, {"X-Goog-IAP-JWT-Assertion": "garbage", "X-Goog-Authenticated-User-Email": "accounts.google.com:founder@vurvesalon.com"}).status_code == 401,
      "forged IAP header with a bad token -> 401 (plain email header is ignored)")
os.environ["DEV_USER"] = "x@y.com"; os.environ["K_SERVICE"] = "svc"
r = c.get("/")
check(r.status_code == 500 and "Sign-in" not in r.get_data(as_text=True) and b"north" not in r.data, "DEV_USER bypass refused (request fails closed) when running on Cloud Run")
print("ALL", ok, "CHECKS PASSED")
