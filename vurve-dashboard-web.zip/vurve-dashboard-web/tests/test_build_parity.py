"""The hosted build_data must reproduce the numbers the published dashboard already shows."""
import json, sys, os
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from refresh import build_data

def run(outlet, emp, inc, ref):
    cfg = json.load(open(os.path.join(os.path.dirname(__file__), "..", "config", "targets.json")))
    new = build_data.build(pd.read_excel(outlet), pd.read_excel(emp), pd.read_excel(inc, sheet_name="Incentive", header=3),
                           cfg["salons"], cfg["tier_months"])
    old = json.load(open(ref))
    assert new["dates"] == old["dates"], "dates differ"
    for a, b in zip(new["salons"], old["salons"]):
        assert a["name"] == b["name"] and a["tier"] == b["tier"], (a["name"], a["tier"], b["tier"])
        assert a["svc"] == b["svc"] and a["newc"] == b["newc"], a["name"]
    assert len(new["staff"]) == len(old["staff"])
    assert sum(1 for s in new["staff"] if s["tgt"]) == sum(1 for s in old["staff"] if s["tgt"])
    build_data.validate(new, old)
    print("parity OK:", len(new["salons"]), "salons,", len(new["staff"]), "staff, through", new["meta"]["data_through"])
    return new

if __name__ == "__main__":
    run(*sys.argv[1:5])
