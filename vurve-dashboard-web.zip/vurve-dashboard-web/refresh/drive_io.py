"""Google Drive / Sheets helpers for the refresh job (read-only)."""
import io

import google.auth
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

SCOPES = [
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/spreadsheets.readonly",
]


def _creds():
    creds, _ = google.auth.default(scopes=SCOPES)
    return creds


def drive():
    return build("drive", "v3", credentials=_creds(), cache_discovery=False)


def sheets():
    return build("sheets", "v4", credentials=_creds(), cache_discovery=False)


def find_file(svc, name, folder_id):
    q = f"'{folder_id}' in parents and name = '{name}' and trashed = false"
    res = svc.files().list(q=q, fields="files(id,name,modifiedTime)", supportsAllDrives=True,
                           includeItemsFromAllDrives=True).execute()
    files = res.get("files", [])
    if not files:
        raise FileNotFoundError(f"{name} not found in Drive folder {folder_id} (is it shared with the service account?)")
    return files[0]


def file_meta(svc, file_id):
    return svc.files().get(fileId=file_id, fields="id,name,modifiedTime", supportsAllDrives=True).execute()


def download(svc, file_id):
    req = svc.files().get_media(fileId=file_id, supportsAllDrives=True)
    buf = io.BytesIO()
    dl = MediaIoBaseDownload(buf, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    return buf.getvalue()


def export_xlsx(svc, file_id):
    """For a native Google Sheet (e.g. the incentive report) export as xlsx."""
    req = svc.files().export_media(
        fileId=file_id, mimeType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    buf = io.BytesIO()
    dl = MediaIoBaseDownload(buf, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    return buf.getvalue()


def read_tab(sh, sheet_id, tab):
    res = sh.spreadsheets().values().get(spreadsheetId=sheet_id, range=tab).execute()
    return res.get("values", [])
