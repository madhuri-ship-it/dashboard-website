"""Turn the 'Vurve Dashboard Access' Google Sheet into access.json.

Tab "Clusters":  Cluster | Salons            (salons separated by commas)
Tab "Users":     Email | Name | Role | Clusters | Salons | Salary
   Role     admin or manager (blank = manager)
   Clusters one or more cluster names from the Clusters tab, comma separated
   Salons   optional extra salon names for that person
   Salary   yes / no (blank = no): may this person see staff salary figures?
"""

YES = {"yes", "y", "true", "1"}


def _rows(values):
    if not values:
        return []
    head = [h.strip().lower() for h in values[0]]
    out = []
    for r in values[1:]:
        r = list(r) + [""] * (len(head) - len(r))
        out.append({head[i]: r[i].strip() for i in range(len(head))})
    return out


def _split(s):
    return [x.strip() for x in s.replace(";", ",").split(",") if x.strip()]


def parse(users_values, cluster_values, salon_names):
    """Returns (access_dict, warnings). Unknown salon/cluster names are reported, never guessed."""
    warnings = []
    canon = {s.lower(): s for s in salon_names}

    def salons_from(text, where):
        found = []
        for name in _split(text):
            hit = canon.get(name.lower())
            if hit:
                found.append(hit)
            else:
                warnings.append(f"{where}: unknown salon '{name}' ignored")
        return found

    clusters = {}
    for r in _rows(cluster_values):
        if r.get("cluster"):
            clusters[r["cluster"]] = salons_from(r.get("salons", ""), f"cluster {r['cluster']}")

    users = {}
    for r in _rows(users_values):
        email = r.get("email", "").lower()
        if not email or "@" not in email:
            continue
        role = "admin" if r.get("role", "").lower() == "admin" else "manager"
        cl = []
        for c in _split(r.get("clusters", "")):
            if c in clusters:
                cl.append(c)
            else:
                warnings.append(f"user {email}: unknown cluster '{c}' ignored")
        users[email] = dict(
            name=r.get("name", ""),
            role=role,
            clusters=cl,
            salons=salons_from(r.get("salons", ""), f"user {email}"),
            salary=r.get("salary", "").lower() in YES,
        )
        if role == "manager" and not cl and not users[email]["salons"]:
            warnings.append(f"user {email}: manager with no clusters or salons will see nothing")
    return {"clusters": clusters, "users": users}, warnings
