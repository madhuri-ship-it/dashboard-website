"""Turn the two Zenoti history sheets (+ staff targets/salary) into the dashboard dataset.

Same logic as the published dashboard, so numbers match what you already see:
  Service ACH       = Service + Packages Rs
  Total revenue     = Service ACH + Product ACH + Membership Sold
  Clients addressed = New Guests + Old Guests
Salon tier = average monthly Service ACH over the months in config 'tier_months'
(Top >= 45L, Mid 25-45L, Low < 25L).
"""
import difflib
import re

import numpy as np
import pandas as pd

DISPLAY = {
    "Vurve - Annanagar": "Anna Nagar",
    "Vurve - Sadashiva Nagar": "Sadashiv Nagar",
    "Vurve - T-Nagar": "T Nagar",
}
REQ_OUTLET = ["Date", "Outlet", "Service ACH", "Product ACH", "Membership Sold"]
REQ_EMP = ["Date", "Outlet", "Staff", "Service", "Packages Rs", "Product ACH", "Membership Sold", "New Guests", "Old Guests"]


class DataError(Exception):
    pass


def _need(df, cols, label):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise DataError(f"{label} is missing columns: {missing}")


def _clean_outlet(df):
    df = df.copy()
    df["Outlet"] = df["Outlet"].replace(DISPLAY).astype(str).str.replace("Vurve - ", "", regex=False)
    df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%Y-%m-%d")
    return df


def build(outlet_df, emp_df, inc_df, targets, tier_months):
    """targets: {"Salon": [monthly_service_target, monthly_product_target]}"""
    _need(outlet_df, REQ_OUTLET, "outlet file")
    _need(emp_df, REQ_EMP, "employee file")
    o = _clean_outlet(outlet_df)
    e = _clean_outlet(emp_df)

    unknown = sorted(set(o.Outlet) - set(targets))
    if unknown:
        raise DataError(f"Outlets in the data but not in targets.json: {unknown}")

    dates = sorted(o.Date.unique())
    ix = {d: i for i, d in enumerate(dates)}
    n = len(dates)

    e["Staff"] = e.Staff.fillna("").astype(str).str.strip().str.replace(r"[\s\-]+$", "", regex=True)
    e["ach"] = e["Service"] + e["Packages Rs"]

    o["M"] = o.Date.str[:7]
    tm = o[o.M.isin(tier_months)]
    avg = tm.groupby("Outlet")["Service ACH"].sum() / max(1, len(tier_months))
    tier = {name: ("Top" if a >= 45e5 else "Mid" if a >= 25e5 else "Low") for name, a in avg.items()}

    def dense(df, col):
        a = np.zeros(n)
        for d, v in df.groupby("Date")[col].sum().items():
            a[ix[d]] = v
        return [round(float(x), 2) for x in a]

    salons = []
    for name, (t, p) in targets.items():
        so, se = o[o.Outlet == name], e[e.Outlet == name]
        salons.append(
            dict(
                name=name,
                tier=tier.get(name, "Low"),
                tgt=t,
                ptgt=p,
                svc=dense(so, "Service ACH"),
                prod=dense(so, "Product ACH"),
                mem=dense(so, "Membership Sold"),
                newc=[int(x) for x in dense(se, "New Guests")],
                oldc=[int(x) for x in dense(se, "Old Guests")],
            )
        )

    inc = inc_df[inc_df.Center.isin(targets.keys())].copy()
    inc["Salary"] = pd.to_numeric(inc.Salary, errors="coerce")
    norm = lambda s: re.sub(r"[^a-z ]", "", str(s).lower()).strip()
    tsort = lambda s: " ".join(sorted(norm(s).split()))
    named = e[(e.Staff != "") & ~e.Staff.str.upper().str.contains("HOUSE")]
    staff = []
    for (out, st), g in named.groupby(["Outlet", "Staff"]):
        gi = inc[inc.Center == out]
        cand = gi[gi.Name.map(norm) == norm(st)]
        if len(cand) == 0:
            cand = gi[gi.Name.map(tsort) == tsort(st)]
        if len(cand) == 0:
            best = [(difflib.SequenceMatcher(None, norm(a), norm(st)).ratio(), i) for i, a in zip(gi.index, gi.Name)]
            best = [x for x in best if x[0] >= 0.85]
            cand = gi.loc[[i for _, i in best]] if best else gi.iloc[0:0]
        if len(cand) == 0:
            s_ = set(norm(re.sub(r"\(.*?\)", "", st)).split())
            hits = []
            for i, a in zip(gi.index, gi.Name):
                at = set(norm(re.sub(r"\(.*?\)", "", str(a))).split())
                al = set(norm(" ".join(re.findall(r"\((.*?)\)", str(a)))).split())
                if at and s_ and (at <= s_ or s_ <= at):
                    hits.append(i)
                elif al and al <= s_:
                    hits.append(i)
            if len(hits) == 1:
                cand = gi.loc[hits]
        tgt = sal = role = None
        if len(cand) >= 1:
            role = cand.Designation.iloc[0]
            role = None if pd.isna(role) else str(role)
        if len(cand) == 1:
            tgt = float(cand["Service Target"].iloc[0]) or None
            s_ = cand.Salary.iloc[0]
            sal = float(s_) if pd.notna(s_) and s_ > 0 else None
        gg = g.groupby("Date")[["ach", "Product ACH", "Membership Sold", "New Guests", "Old Guests"]].sum()
        rows = [
            [ix[d], round(float(r.ach), 1), round(float(r["Product ACH"]), 1), round(float(r["Membership Sold"]), 1),
             int(r["New Guests"]), int(r["Old Guests"])]
            for d, r in gg.iterrows()
            if (r.values != 0).any()
        ]
        if rows:
            staff.append(dict(outlet=out, name=st, role=role, tgt=tgt, sal=sal, d=rows))

    return dict(dates=dates, salons=salons, staff=staff, meta=dict(data_through=dates[-1]))


def validate(new, prev):
    """Refuse a rebuild that looks wrong instead of publishing it. Raises DataError."""
    if not new["salons"] or not new["staff"]:
        raise DataError("new dataset has no salons or no staff")
    if prev:
        if len(new["dates"]) < len(prev["dates"]):
            raise DataError("new data has fewer days than the published data")
        if new["dates"][-1] < prev["dates"][-1]:
            raise DataError("new data ends earlier than the published data")
        cut = max(0, len(prev["dates"]) - 4)  # ignore the latest days, they may be restated
        for ns, ps in zip(new["salons"], prev["salons"]):
            a, b = sum(ns["svc"][:cut]), sum(ps["svc"][:cut])
            if b and abs(a - b) / b > 0.01:
                raise DataError(f"history changed for {ns['name']} ({b:,.0f} -> {a:,.0f}); not published. Re-run with --force if intended")
    return True
