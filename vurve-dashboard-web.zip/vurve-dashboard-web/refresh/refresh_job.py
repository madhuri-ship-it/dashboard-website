"""Scheduled refresh (Cloud Run job). Safe to run as often as you like:
it only rebuilds when the Drive files or the access sheet have changed.

Environment:
  DATA_BUCKET            private GCS bucket for data.json / access.json / state.json / config/
  DRIVE_FOLDER_ID        folder holding the two history workbooks
  OUTLET_FILE_NAME       default outlet_sales_history_2026.xlsx
  EMP_FILE_NAME          default employee_history_2026.xlsx
  ACCESS_SHEET_ID        Google Sheet with tabs "Users" and "Clusters"
  INCENTIVE_FILE_ID      optional: Drive id of the incentive report; if unset, config/incentive.xlsx in the bucket is used
  FORCE=1 or --force     rebuild even if nothing changed / accept restated history
"""
import io
import json
import os
import sys
import traceback
from datetime import datetime, timezone

import pandas as pd

from app import store
from refresh import access_sheet, build_data, drive_io

HERE = os.path.dirname(__file__)


def log(event, **kw):
    print(json.dumps({"event": event, **kw}, default=str), flush=True)


def load_targets():
    cfg = store.read_json("config/targets.json", default=None, cached=False)
    if cfg is None:
        with open(os.path.join(HERE, "..", "config", "targets.json")) as f:
            cfg = json.load(f)
    return cfg


def main(force=False):
    force = force or os.environ.get("FORCE") == "1" or "--force" in sys.argv
    folder = os.environ["DRIVE_FOLDER_ID"]
    out_name = os.environ.get("OUTLET_FILE_NAME", "outlet_sales_history_2026.xlsx")
    emp_name = os.environ.get("EMP_FILE_NAME", "employee_history_2026.xlsx")

    dsv = drive_io.drive()
    f_out = drive_io.find_file(dsv, out_name, folder)
    f_emp = drive_io.find_file(dsv, emp_name, folder)
    state = store.read_json("state.json", default={}, cached=False)

    sheet_id = os.environ.get("ACCESS_SHEET_ID")
    access_changed = False
    if sheet_id:
        try:
            sm = drive_io.file_meta(dsv, sheet_id)
            access_changed = sm["modifiedTime"] != state.get("access_mtime")
        except Exception as exc:
            log("access_meta_error", error=str(exc))

    data_changed = (f_out["modifiedTime"] != state.get("outlet_mtime")) or (f_emp["modifiedTime"] != state.get("emp_mtime"))
    if not (data_changed or access_changed or force):
        log("nothing_to_do", outlet=f_out["modifiedTime"], emp=f_emp["modifiedTime"])
        return 0

    if data_changed or force:
        cfg = load_targets()
        o = pd.read_excel(io.BytesIO(drive_io.download(dsv, f_out["id"])))
        e = pd.read_excel(io.BytesIO(drive_io.download(dsv, f_emp["id"])))
        inc_id = os.environ.get("INCENTIVE_FILE_ID")
        if inc_id:
            inc_bytes = drive_io.export_xlsx(dsv, inc_id)
        else:
            inc_bytes = store.read_bytes("config/incentive.xlsx")
            if not inc_bytes:
                raise RuntimeError("config/incentive.xlsx not found in the bucket and INCENTIVE_FILE_ID not set")
        inc = pd.read_excel(io.BytesIO(inc_bytes), sheet_name="Incentive", header=3)
        new = build_data.build(o, e, inc, cfg["salons"], cfg["tier_months"])
        new["meta"]["generated_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        prev = store.read_json("data.json", default=None, cached=False)
        if not force:
            build_data.validate(new, prev)
        store.write_json("data.json", new)
        state.update(outlet_mtime=f_out["modifiedTime"], emp_mtime=f_emp["modifiedTime"],
                     data_through=new["meta"]["data_through"])
        log("data_published", through=new["meta"]["data_through"], salons=len(new["salons"]), staff=len(new["staff"]))

    if sheet_id and (access_changed or data_changed or force):
        try:
            full = store.read_json("data.json", default=None, cached=False)
            sh = drive_io.sheets()
            users = drive_io.read_tab(sh, sheet_id, "Users")
            clusters = drive_io.read_tab(sh, sheet_id, "Clusters")
            access, warns = access_sheet.parse(users, clusters, [s["name"] for s in full["salons"]])
            for w in warns:
                log("access_warning", message=w)
            if access["users"]:
                store.write_json("access.json", access)
                state["access_mtime"] = drive_io.file_meta(dsv, sheet_id)["modifiedTime"]
                log("access_published", users=len(access["users"]), clusters=len(access["clusters"]))
            else:
                log("access_error", message="sheet produced no users; keeping the previous access.json")
        except Exception as exc:
            log("access_error", message=str(exc))

    state["last_run_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    store.write_json("state.json", state)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        log("refresh_failed", trace=traceback.format_exc())
        sys.exit(1)  # non-zero so Cloud Run / alerts show the failure; old data stays published
